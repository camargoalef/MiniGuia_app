# Mini Guia - Guatapará (v2.0)

## 📖 Descrição do Projeto

Esta é a segunda versão do aplicativo "Mini Guia - Guatapará", desenvolvida como parte da evolução do projeto para a disciplina de **[<-- COLOQUE O NOME DA DISCIPLINA AQUI]**. A versão anterior, que era um guia estático, foi completamente refatorada para se tornar um aplicativo dinâmico, performático e interativo.

As principais melhorias incluem a troca da `ListView` por uma `RecyclerView` para melhor performance, a persistência de dados com o banco de dados **Room**, e a adição de uma funcionalidade completa de **cadastro de novos estabelecimentos**, permitindo que o aplicativo cresça com a contribuição dos usuários.

---

## ✨ Funcionalidades Principais

*   **Lista Dinâmica e Performática:** A tela principal agora usa uma `RecyclerView`, garantindo uma rolagem suave e eficiente, mesmo com muitos itens.
*   **Banco de Dados Local (Room):** Todos os serviços são salvos em um banco de dados local. Os dados persistem mesmo se o aplicativo for fechado e reaberto.
*   **Cadastro de Novos Serviços:**
    *   Uma nova tela de cadastro permite que o usuário adicione novos estabelecimentos.
    *   Funcionalidade para **escolher uma imagem da galeria** do celular para o novo serviço.
*   **Busca em Tempo Real:** Uma barra de busca na tela principal filtra a lista de serviços conforme o usuário digita.
*   **Navegação Moderna:** A comunicação entre as telas de lista e cadastro utiliza o `ActivityResultLauncher`, a abordagem moderna do Android.
*   **Layouts Otimizados:** Todas as telas foram refatoradas para usar `ConstraintLayout`, seguindo as melhores práticas de UI do Android.

---

## 📸 Screenshots

### Demonstração das Funcionalidades

| Lista Principal com Busca | Tela de Cadastro | Tela de Detalhes |
| :---: | :---: | :---: |
| ![Tela Principal](URL_PARA_IMAGEM_TELA_PRINCIPAL.png) | ![Tela de Cadastro](URL_PARA_IMAGEM_TELA_CADASTRO.png) | ![Tela de Detalhes](URL_PARA_IMAGEM_TELA_DETALHES.png) |

---

## 🎥 Vídeo Curto de Demonstração (30s)

*Instruções: Grave um vídeo curto (ou GIF) mostrando as funcionalidades principais: rolar a lista, usar a busca, clicar no botão '+', preencher (rapidamente) e salvar um novo item, e ver o item novo aparecer na lista. Substitua o link abaixo.*

![Vídeo de Demonstração](URL_PARA_VIDEO_OU_GIF.gif)

---

## 👨‍🏫 Vídeo Explicativo do Código (5-10 min)

*Instruções: Faça o upload do seu vídeo mais longo no YouTube (como "Não Listado") ou Google Drive (com link público) e coloque o link aqui.*

**Link para o vídeo:** [Assista à explicação detalhada do código aqui](URL_PARA_SEU_VIDEO_LONGO)

---

## 🛠️ Tecnologias Utilizadas

*   **Linguagem:** Kotlin
*   **Arquitetura e Padrões:**
    *   Organização em pacotes (data, ui, model, etc.).
    *   Padrão Singleton para a instância do banco de dados.
*   **Interface Gráfica (UI):**
    *   `RecyclerView` com `ListAdapter` para uma lista performática e otimizada.
    *   `ConstraintLayout` como base para todas as telas.
    *   `ViewBinding` para acesso seguro aos componentes visuais.
*   **Persistência de Dados:**
    *   `Room Persistence Library` para o banco de dados local (SQLite).
    *   `DAO` (Data Access Object) para definir as operações do banco.
    *   `LiveData` para observar as mudanças no banco e atualizar a UI automaticamente.
*   **Componentes do Android Jetpack:**
    *   `ActivityResultLauncher` para a seleção de imagens da galeria e comunicação entre Activities.
    *   Intents para navegação entre as telas.
