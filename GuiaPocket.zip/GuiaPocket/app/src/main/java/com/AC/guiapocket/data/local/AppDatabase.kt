package com.AC.guiapocket.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.AC.guiapocket.R
import com.AC.guiapocket.data.model.Service
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Service::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun serviceDao(): ServiceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "service_database"
                )
                .addCallback(AppDatabaseCallback(context))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let {
                CoroutineScope(Dispatchers.IO).launch {
                    prepopulateDatabase(context, it.serviceDao())
                }
            }
        }

        suspend fun prepopulateDatabase(context: Context, serviceDao: ServiceDao) {
            val services = listOf(
                Service(
                    name = "Lanchonete Kidelicia",
                    category = "Alimentação",
                    description = "Porções caprichadas e aquele podrão que mata a fome de verdade.",
                    imageUri = getUriFromDrawable(context, R.drawable.kidelicia),
                    phone = "01639730245",
                    websiteUrl = "https://kidelicia.com.br/",
                    latitude = -21.49527372975833,
                    longitude = -48.03573424218543
                ),
                Service(
                    name = "Supermercado Rubinho",
                    category = "Mercado",
                    description = "O maior supermercado da cidade.",
                    imageUri = getUriFromDrawable(context, R.drawable.supermercado_rubinho),
                    phone = "01639730220",
                    websiteUrl = "https://www.instagram.com/supermercadorubinho/",
                    latitude = -21.496064854002004,
                    longitude = -48.03836008597214
                ),
                Service(
                    name = "Arena Rubinho",
                    category = "Lazer",
                    description = "Comida caseira. Além de boas refeições, o estabelecimento conta com uma quadra poliesportiva.",
                    imageUri = getUriFromDrawable(context, R.drawable.arena_rubinho),
                    phone = "16999993333",
                    websiteUrl = "https://www.instagram.com/rubinhoarena/",
                    latitude = -21.498021424057452,
                    longitude = -48.03781291533146
                ),
                Service(
                    name = "Princce Hotel",
                    category = "Hotel",
                    description = "Único hotel da cidade, oferece hospedagem confortável e fácil acesso aos principais pontos locais.",
                    imageUri = getUriFromDrawable(context, R.drawable.princce_hotel),
                    phone = "01639730010",
                    websiteUrl = "https://princehotel.com.br/",
                    latitude = -21.49691336978993,
                    longitude = -48.03296348145521
                ),
                Service(
                    name = "Quiosque do Pastel",
                    category = "Pastelaria",
                    description = "Ponto conhecido pelos pastéis variados e preparados na hora.",
                    imageUri = getUriFromDrawable(context, R.drawable.quiosque_do_pastel),
                    phone = "01639731135",
                    websiteUrl = "https://www.pastelaria.com.br/",
                    latitude = -21.497519805937557,
                    longitude = -48.03915670208317
                ),
                Service(
                    name = "Clínica Dr. Danilo Selli",
                    category = "Clínica Odontológica",
                    description = "Oferece atendimentos em diversas especialidades no ramo odontológico.",
                    imageUri = getUriFromDrawable(context, R.drawable.clinica),
                    phone = "016988481143",
                    websiteUrl = "https://odontocompany.com/",
                    latitude = -21.497808397773714,
                    longitude = -48.0375175283452
                )
            )
            services.forEach { serviceDao.insert(it) }
        }

        fun getUriFromDrawable(context: Context, drawableId: Int): String {
            return "android.resource://${context.packageName}/$drawableId"
        }
    }
}