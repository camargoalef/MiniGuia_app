package com.AC.guiapocket.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.AC.guiapocket.data.model.Service

@Dao
interface ServiceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(service: Service)

    @Query("SELECT * FROM services ORDER BY name ASC")
    fun getAllServices(): LiveData<List<Service>>

    @Query("SELECT * FROM services WHERE name LIKE :query ORDER BY name ASC")
    fun searchServices(query: String): LiveData<List<Service>>
}