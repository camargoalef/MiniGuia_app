package com.AC.guiapocket.ui.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.AC.guiapocket.R
import com.AC.guiapocket.data.local.AppDatabase
import com.AC.guiapocket.data.model.Service
import com.AC.guiapocket.databinding.ActivityDetailBinding
import kotlinx.coroutines.launch

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var database: AppDatabase
    private var service: Service? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Habilita o botão de "voltar" na barra de ação
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        database = AppDatabase.getDatabase(this)

        val serviceId = intent.getLongExtra("service_id", -1)

        if (serviceId != -1L) {
            loadService(serviceId)
        }

        setupListeners()
    }

    // Lida com o clique no botão de "voltar" da barra de ação
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun loadService(serviceId: Long) {
        lifecycleScope.launch {
            database.serviceDao().getAllServices().observe(this@DetailActivity) { services ->
                service = services.find { it.id == serviceId }
                service?.let { setupViews(it) }
            }
        }
    }

    private fun setupViews(service: Service) {
        binding.tvDetailName.text = service.name
        binding.tvDetailCategory.text = service.category
        binding.tvDetailDescription.text = service.description
        if (service.imageUri.isNotEmpty()) {
            binding.ivDetailImage.setImageURI(Uri.parse(service.imageUri))
        }
    }

    private fun setupListeners() {
        binding.btnCall.setOnClickListener {
            service?.let { callService(it.phone) }
        }

        binding.btnWebsite.setOnClickListener {
            service?.let { openWebsite(it.websiteUrl) }
        }

        binding.btnMap.setOnClickListener {
            service?.let { openMap(it.latitude, it.longitude) }
        }
    }

    private fun callService(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_call_fail, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openWebsite(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_website_fail, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openMap(lat: Double, lon: Double) {
        val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon(${service?.name})")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_map_fail, Toast.LENGTH_SHORT).show()
        }
    }
}