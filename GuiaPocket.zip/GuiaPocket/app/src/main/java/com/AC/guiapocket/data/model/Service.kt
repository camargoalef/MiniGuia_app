package com.AC.guiapocket.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "services")
data class Service(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val description: String,
    val imageUri: String,
    val phone: String,
    val websiteUrl: String,
    val latitude: Double,
    val longitude: Double
) : Serializable