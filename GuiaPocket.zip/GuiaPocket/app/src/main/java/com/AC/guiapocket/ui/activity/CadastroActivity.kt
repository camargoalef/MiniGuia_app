package com.AC.guiapocket.ui.activity

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.AC.guiapocket.R
import com.AC.guiapocket.data.local.AppDatabase
import com.AC.guiapocket.data.model.Service
import com.AC.guiapocket.databinding.ActivityCadastroBinding
import kotlinx.coroutines.launch

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var database: AppDatabase
    private var selectedImageUri: Uri? = null

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) {
        uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            binding.ivServicePhoto.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        setupListeners()
    }

    private fun setupListeners() {
        binding.btnSelectPhoto.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        binding.btnSave.setOnClickListener {
            saveService()
        }
    }

    private fun saveService() {
        val name = binding.etName.text.toString().trim()
        val category = binding.etCategory.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val website = binding.etWebsite.text.toString().trim()
        val latitude = binding.etLatitude.text.toString().toDoubleOrNull() ?: 0.0
        val longitude = binding.etLongitude.text.toString().toDoubleOrNull() ?: 0.0

        if (name.isEmpty() || category.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, R.string.form_validation_error, Toast.LENGTH_SHORT).show()
            return
        }

        val newService = Service(
            name = name,
            category = category,
            description = description,
            imageUri = selectedImageUri.toString(),
            phone = phone,
            websiteUrl = website,
            latitude = latitude,
            longitude = longitude
        )

        lifecycleScope.launch {
            database.serviceDao().insert(newService)
            setResult(Activity.RESULT_OK)
            finish() // Fecha a tela de cadastro e volta para a MainActivity
        }
    }
}