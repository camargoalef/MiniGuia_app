package com.AC.guiapocket.ui.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.AC.guiapocket.data.local.AppDatabase
import com.AC.guiapocket.databinding.ActivityMainBinding
import com.AC.guiapocket.ui.adapter.ServiceAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: AppDatabase
    private lateinit var adapter: ServiceAdapter

    private val newServiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            // O LiveData já atualiza a lista automaticamente, mas poderíamos
            // exibir um Toast ou fazer outra ação aqui se quiséssemos.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        setupRecyclerView()
        setupSearch()
        setupListeners()
        observeServices()
    }

    private fun setupRecyclerView() {
        adapter = ServiceAdapter { service ->
            val intent = Intent(this, DetailActivity::class.java).apply {
                putExtra("service_id", service.id)
            }
            startActivity(intent)
        }
        binding.rvServices.layoutManager = LinearLayoutManager(this)
        binding.rvServices.adapter = adapter
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener {
            searchServices(it.toString())
        }
    }

    private fun setupListeners() {
        binding.fabAddService.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            newServiceLauncher.launch(intent)
        }
    }

    private fun observeServices() {
        database.serviceDao().getAllServices().observe(this, Observer {
            adapter.submitList(it)
        })
    }

    private fun searchServices(query: String) {
        val searchQuery = "%${query}%"
        database.serviceDao().searchServices(searchQuery).observe(this, Observer {
            adapter.submitList(it)
        })
    }
}